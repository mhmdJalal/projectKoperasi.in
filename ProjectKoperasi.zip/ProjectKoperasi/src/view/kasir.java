package view;

/*
* Created by Muhamad Jalaludin
*/

import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.sql.*;
import java.util.Date;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.text.SimpleDateFormat;
import javax.swing.table.DefaultTableModel;

public class kasir extends javax.swing.JFrame {
    
    public Statement st;
    public ResultSet rs;
    public DefaultTableModel tabModel;
    public PreparedStatement ps;
    Connection cn = koneksi.koneksiDB.getKoneksi();
    int harga,jumlah,total, bayar, kembalian;
    
    
    public kasir() {
        initComponents();
        fillCombobarang();
        auto_key();
        judul();
        setJam();
        Date date = new Date();
        tanggal.setDate(date);
        reset();
        this.setLocationRelativeTo(null);
        tstok.hide();
        kodebarang.hide();
        tdatetime.hide();
        tstok.setText("");
        batal.setEnabled(false);
        bcetak.setEnabled(false);
        simpan.setEnabled(false);
        tambah.setEnabled(false);
        batal.setEnabled(false);
        kosong.setEnabled(false);
        tbayar.setEnabled(false);
        transaksi.setEnabled(false);
        hargahir.setEnabled(false);
        tjmlh.setEnabled(false);
        loadData();
    }
    
    private void setJam(){
    ActionListener taskPerformer;
        taskPerformer = (ActionEvent evt) -> {
            String nol_jam = "", nol_menit = "",nol_detik = "";
            java.util.Date dateTime = new java.util.Date();
            int nilai_jam = dateTime.getHours();
            int nilai_menit = dateTime.getMinutes();
            int nilai_detik = dateTime.getSeconds();
            if(nilai_jam <= 9) nol_jam= "0";
            if(nilai_menit <= 9) nol_menit= "0";
            if(nilai_detik <= 9) nol_detik= "0";
            String jam = nol_jam + Integer.toString(nilai_jam);
            String menit = nol_menit + Integer.toString(nilai_menit);
            String detik = nol_detik + Integer.toString(nilai_detik);
            waktu.setText(jam+":"+menit+":"+detik+"");
    };
    new Timer(1000, taskPerformer).start();
    }
    
    private void judul() {
        String judul[]= {
            "Kode Barang", 
            "Nama Barang", 
            "Harga Barang", 
            "Jumlah", 
            "Subtotal"
        };
        tabModel = new DefaultTableModel(judul, 0);
        keranjang.setModel(tabModel);
    }
    
    private void reset(){
        namabarang.setSelectedItem("-Pilih Nama Barang-");
        kdbarang.setText("");
        hgbarang.setText("");
        tjmlh.setText("");
        subtotal.setText("");
        tbayar.setText("");
        jkembalian.setText("");
        kodebarang.setText("");
        kodebarang.setText("");
        tdatetime.setText("");
        tstok.setText("");
   }
    
    private void fillCombobarang() {
        try{
            st = cn.createStatement();
            rs = st.executeQuery("Select * from tb_barang");
            while (rs.next()) {
                String data =  rs.getString("nm_barang");
                namabarang.addItem(data);
            }
        } catch(SQLException e){
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    private void Batal(){
        int x, y, z;
        x = Integer.parseInt(tstok.getText());
        y = Integer.parseInt(tjmlh.getText());
        z = x+y;
        
        try{
            st = cn.createStatement();
            String sql ="UPDATE tb_barang set jumlah='"+ z +"' WHERE kd_barang='"+ kodebarang.getText() +"'";  
            st.executeUpdate(sql);
            tstok.setText("");
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
     
        //Proses mengahapus data dari tabel keranjang
        try {
            st = cn.createStatement();
            String sql="DELETE From tb_jualdetail WHERE kd_barang='"+ kodebarang.getText()+"'";
            st.executeUpdate(sql);
            loadData();
            JOptionPane.showMessageDialog(this,"Sukses Hapus Data...");
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        loadData();
    }
    
    private void cari_kode(){
        int i=keranjang.getSelectedRow();
        if (i<0) {
            return;
        }
        String id=(String)tabModel.getValueAt(i, 0);
        kodebarang.setText(id);
    }
    
    private void ShowData(){
        try {
            st = cn.createStatement();
            String sql="Select * from q_keranjang"; 
            rs = st.executeQuery(sql);
            while(rs.next()){
                kdbarang.setText(rs.getString("kd_barang"));
                tjmlh.setText(rs.getString("jumlah_qty"));
//                namabarang.setSelectedItem(rs.getString("nm_barang"));
                hgbarang.setText(rs.getString("harga_barang"));
                subtotal.setText(rs.getString("subtotal"));
            }
        }catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    private void ShowSisa(){
        try {
            String sql="Select * from  tb_barang WHERE kd_barang ='"+kodebarang.getText()+"'"; 
            st = cn.createStatement();
            rs = st.executeQuery(sql);
            while(rs.next()){
                tstok.setText(rs.getString("jumlah"));      
            }
        }catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    private void UpdateStock(){
        int x, y, z;
        x = Integer.parseInt(tstok.getText());
        y = Integer.parseInt(tjmlh.getText());
        z = x - y;

        try{
            st = cn.createStatement();
            String sql ="UPDATE tb_barang set jumlah='"+ z +"' WHERE kd_barang='"+ kdbarang.getText() +"'";  
            st.executeUpdate(sql);
        }catch(SQLException e){  
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    private void loadData(){
        tabModel.getDataVector().removeAllElements();
        tabModel.fireTableDataChanged();
        try {
            st = cn.createStatement();
            String sql = "select * from q_keranjang";
            rs = st.executeQuery(sql);
            while (rs.next()) {                
                Object data[]={
                    rs.getString("kd_barang"),
                    rs.getString("nm_barang"),
                    rs.getString("harga_barang"),
                    rs.getString("jumlah_qty"),
                    rs.getString("subtotal")
                };
                tabModel.addRow(data);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        
        //untuk menghitung total data yang terdapat dalam database
        total = 0;
        for (int i =0; i< keranjang.getRowCount(); i++){
            int amount = Integer.parseInt((String)keranjang.getValueAt(i, 4));
            total += amount;
        }
        hargahir.setText(""+total);
    }
    
    
    private void auto_key(){  
        try {  
            java.util.Date tgl = new java.util.Date();  
            java.text.SimpleDateFormat kal = new java.text.SimpleDateFormat("yyMMdd");  
            java.text.SimpleDateFormat ttanggal = new java.text.SimpleDateFormat("yyyyMMdd");  
            
            String sql = "select max(no_transaksi) from tb_jual WHERE tanggal ="+ttanggal.format(tgl);   
            st = cn.createStatement();  
            rs = st.executeQuery(sql);  
            while(rs.next()){  
                Long a =rs.getLong(1); 
                if(a == 0){  
                    this.transaksi.setText(kal.format(tgl)+"0000"+(a+1));  
                }else{  
                    this.transaksi.setText(""+(a+1));  
                }  
            }
        }  
        catch (SQLException e) {  
            JOptionPane.showMessageDialog(null, e.getMessage());  
        }  
    }
    
    public void autoSum() {     
        int a, b, c;
        a = Integer.parseInt(hgbarang.getText());
        b = Integer.parseInt(tjmlh.getText());
        c = a*b;
        subtotal.setText(""+c);
    }
    
    public void HitungKembali() {     
        int d, e, f;
        d = Integer.parseInt(subtotal.getText());
        e = Integer.parseInt(hgbarang.getText());
        f = e-d;
        jkembalian.setText(""+f);
    }
    
    //untuk menambahkan ke tabel keranjang
    public void TambahDetail(){
        try {
            st = cn.createStatement();
            
            String sql = "Select * from tb_jualdetail";
            rs = st.executeQuery(sql);
            
            if (rs.first() == false) {
                st.executeUpdate("Insert into tb_jualdetail values ('"+ kdbarang.getText() +"', '"+ tjmlh.getText() +"', '"+ subtotal.getText() +"')");
                JOptionPane.showMessageDialog(null, "Berhasil ditambahkan ke keranjang");
            } else {
                
                String sql2 = "Select * from tb_jualdetail where kd_barang = '"+ kdbarang.getText() +"'";
                rs = st.executeQuery(sql2);

                if (rs.next()) {
                    int jumlah = Integer.parseInt(tjmlh.getText());
                    total = Integer.parseInt(subtotal.getText());
                    int totalharga = Integer.parseInt(rs.getString("subtotal"));    
                    int jmlhqty = 0;
                    
                    for (int i =0; i < keranjang.getRowCount(); i++){
                        jmlhqty = Integer.parseInt(rs.getString("jumlah_qty"));
                        jmlhqty += jumlah;
                    }
                    total += totalharga;
                    st.executeUpdate("Update tb_jualdetail set jumlah_qty = '"+ jmlhqty +"', subtotal = '"+ total +"' where kd_barang = '"+ kdbarang.getText() +"'");
                    JOptionPane.showMessageDialog(null, "Berhasil ditambahkan kembali ke keranjang!");
                
                } else {
                    st.executeUpdate("Insert into tb_jualdetail values ('"+ kdbarang.getText() +"', '"+ tjmlh.getText() +"', '"+ subtotal.getText() +"')");
                    JOptionPane.showMessageDialog(null, "Berhasil ditambahkan ke keranjang");
                }
            rs.close();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void Selesai(){
        Date stanggal = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss"); 
        stanggal = tanggal.getDate(); 
        String dtanggal = dateFormat.format(stanggal);
            
        total = 0;
        for (int i = 0; i < keranjang.getRowCount(); i++) {
            int amount = Integer.parseInt((String)keranjang.getValueAt(i, 3));
            total += amount;
        }
        
        try{
            for (int i = 0; i < keranjang.getRowCount(); i++) {
                String sql="Insert into tb_jual values ('"+ transaksi.getText() +"', '"+ keranjang.getValueAt(i, 0) +"','"+ keranjang.getValueAt(i, 4) +"', '"+ keranjang.getValueAt(i, 3) +"', '"+ tbayar.getText() +"', '"+ jkembalian.getText() +"','"+ dtanggal +"', '"+waktu.getText()+"')";  
                st = cn.createStatement();
                st.executeUpdate(sql);
            }
            
            
            JOptionPane.showMessageDialog(null, "Data Tersimpan!");
            loadData();
        }catch(SQLException e){ 
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        loadData();
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        close = new javax.swing.JLabel();
        mini = new javax.swing.JLabel();
        waktu = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        hgbarang = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        batal = new javax.swing.JButton();
        subtotal = new javax.swing.JTextField();
        simpan = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        tjmlh = new javax.swing.JTextField();
        tstok = new javax.swing.JTextField();
        kodebarang = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        tdatetime = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        tbayar = new javax.swing.JTextField();
        kosong = new javax.swing.JButton();
        breset = new javax.swing.JButton();
        jkembalian = new javax.swing.JLabel();
        bcetak = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        transaksi = new javax.swing.JTextField();
        namabarang = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        keranjang = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        hargahir = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        kdbarang = new javax.swing.JTextField();
        tanggal = new com.toedter.calendar.JDateChooser();
        jLabel16 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        tambah = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Halaman Kasir");
        setUndecorated(true);
        setPreferredSize(new java.awt.Dimension(760, 591));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(52, 152, 219));

        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Jl.Raya Wangun Kelurahan Sindangsari Kec. Bogor Timur Kota Bogor");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Jawa Barat, Indonesia");

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/barang2.png"))); // NOI18N
        jLabel12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel12MouseClicked(evt);
            }
        });

        close.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        close.setForeground(new java.awt.Color(255, 255, 255));
        close.setText("X");
        close.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                closeMouseClicked(evt);
            }
        });

        mini.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        mini.setForeground(new java.awt.Color(255, 255, 255));
        mini.setText("-");
        mini.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                miniMouseClicked(evt);
            }
        });

        waktu.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        waktu.setForeground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Berlin Sans FB", 0, 27)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Koperasi.In");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(mini)
                        .addGap(18, 18, 18)
                        .addComponent(close))
                    .addComponent(waktu, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator1)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel2))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(close)
                        .addComponent(mini)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(waktu, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel12)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(236, 240, 241));

        jLabel6.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel6.setText("Harga satuan");

        hgbarang.setToolTipText("");
        hgbarang.setEnabled(false);

        jLabel7.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel7.setText("Qty");

        batal.setText("Batal");
        batal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                batalActionPerformed(evt);
            }
        });

        subtotal.setEnabled(false);

        simpan.setText("Simpan");
        simpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                simpanActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel8.setText("Sub total");

        tjmlh.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tjmlhKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tjmlhKeyTyped(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel9.setText("Bayar");

        jLabel10.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel10.setText("Kembalian");

        jLabel15.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        jLabel15.setText("Keranjang Pembelian");

        tbayar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tbayarKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tbayarKeyTyped(evt);
            }
        });

        kosong.setText("Kosongkan Keranjang");
        kosong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kosongActionPerformed(evt);
            }
        });

        breset.setText("Reset");
        breset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bresetActionPerformed(evt);
            }
        });

        bcetak.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/printer.png"))); // NOI18N
        bcetak.setText("Cetak");
        bcetak.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcetakActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel11.setText("No. Faktur");

        transaksi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                transaksiActionPerformed(evt);
            }
        });

        namabarang.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-Pilih Nama Barang-" }));
        namabarang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                namabarangActionPerformed(evt);
            }
        });

        keranjang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6"
            }
        ));
        keranjang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                keranjangMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(keranjang);

        jPanel2.setBackground(new java.awt.Color(236, 240, 241));

        hargahir.setEditable(false);
        hargahir.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel13.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel13.setText("Total Pembelian (Rp)");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel13)
                .addContainerGap(249, Short.MAX_VALUE))
            .addComponent(hargahir)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(hargahir, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jLabel4.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel4.setText("Kode Barang");

        jLabel5.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel5.setText("Nama Barang");

        jLabel14.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel14.setText("Tanggal");

        kdbarang.setToolTipText("");
        kdbarang.setEnabled(false);

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-buying-64.png"))); // NOI18N

        jPanel4.setBackground(new java.awt.Color(236, 240, 241));

        tambah.setText("Tambah");
        tambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tambahActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(77, Short.MAX_VALUE)
                .addComponent(tambah))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(tambah))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(kdbarang, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(hgbarang, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tjmlh, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(subtotal, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(batal, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel11)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel14)
                                    .addComponent(jLabel5))
                                .addGap(39, 39, 39)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(transaksi)
                                    .addComponent(tanggal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(namabarang, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel3Layout.createSequentialGroup()
                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel10)
                                        .addComponent(jLabel9))
                                    .addGap(50, 50, 50)
                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(tbayar, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(jPanel3Layout.createSequentialGroup()
                                            .addComponent(jkembalian, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(47, 47, 47)
                                            .addComponent(simpan))))
                                .addGroup(jPanel3Layout.createSequentialGroup()
                                    .addComponent(bcetak)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(breset)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(kosong)))
                            .addGap(40, 40, 40)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(kodebarang)
                                .addComponent(tstok)
                                .addComponent(tdatetime, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(136, 136, 136))
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addComponent(jLabel16)
                            .addGap(18, 18, 18)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel15)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 564, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(25, 25, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(transaksi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel14)
                            .addComponent(tanggal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(namabarang)
                            .addComponent(jLabel5)))
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(kdbarang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(hgbarang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tjmlh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(subtotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(batal)
                        .addGap(7, 7, 7)))
                .addGap(8, 8, 8)
                .addComponent(jLabel15)
                .addGap(9, 9, 9)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(tbayar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel10)
                                    .addComponent(simpan)
                                    .addComponent(jkembalian, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(breset)
                                        .addComponent(kosong))
                                    .addComponent(bcetak))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addGap(0, 10, Short.MAX_VALUE)
                                .addComponent(tstok, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(kodebarang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(tdatetime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap(24, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void closeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_closeMouseClicked
        try {
            int jawab;
            if((jawab = JOptionPane.showConfirmDialog(null, "Anda yakin ingin keluar dari program?", "Konfirmasi", JOptionPane.YES_NO_OPTION)) == 0){
                st = cn.createStatement();
                st.executeUpdate("Truncate tb_jualdetail");
                System.exit(0);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }//GEN-LAST:event_closeMouseClicked

    private void jLabel12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel12MouseClicked
        utama tm = new utama();
        tm.show();
        this.dispose();
    }//GEN-LAST:event_jLabel12MouseClicked

    private void keranjangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_keranjangMouseClicked
        cari_kode();
        ShowData();
        ShowSisa();
        batal.setEnabled(true);
        tjmlh.setEnabled(true);
    }//GEN-LAST:event_keranjangMouseClicked

    private void namabarangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_namabarangActionPerformed
        try {
            if (namabarang.getSelectedItem()=="-Pilih Nama Barang-") {
                kdbarang.setText("");
                hgbarang.setText("");
            } else{
                String sql = "SELECT * FROM tb_barang where nm_barang='"+ namabarang.getSelectedItem() +"'";
                rs = st.executeQuery(sql);  
                while (rs.next()) {
                    kdbarang.setText(rs.getString("kd_barang"));
                    hgbarang.setText(rs.getString("harga_barang"));
                    tstok.setText(rs.getString("jumlah"));
                }                
                tjmlh.setEnabled(true);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }//GEN-LAST:event_namabarangActionPerformed

    private void bcetakActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcetakActionPerformed
        try {
            Desktop.getDesktop().browse(new URL("http://localhost:81/koperasi/Cetak/cetak/"+transaksi.getText()).toURI());
            auto_key();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }//GEN-LAST:event_bcetakActionPerformed

    private void bresetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bresetActionPerformed
        if ("".equals(kdbarang.getText()) && "".equals(tjmlh.getText())) {
            JOptionPane.showMessageDialog(null, "Data Kosong!");
        }else reset();
    }//GEN-LAST:event_bresetActionPerformed

    private void kosongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kosongActionPerformed
        try {
            int jawab;
            if( (jawab = JOptionPane.showConfirmDialog(null, "Anda yakin ingin menghapus daftar pembelian?", "Konfirmasi", JOptionPane.YES_NO_OPTION)) == 0){
                st = cn.createStatement();
                st.executeUpdate("TRUNCATE tb_jualdetail");
                loadData();
                tjmlh.setEnabled(false);
                tbayar.setEnabled(false);
                kosong.setEnabled(false);
                simpan.setEnabled(false);
                bcetak.setEnabled(false);
                JOptionPane.showMessageDialog(null, "Berhasil kosongkan keranjang pembelian!");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }//GEN-LAST:event_kosongActionPerformed

    private void tbayarKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbayarKeyTyped
        char jmlh = evt.getKeyChar();
        if (!(Character.isDigit(jmlh) || (jmlh==KeyEvent.VK_BACK_SPACE) || jmlh==KeyEvent.VK_DELETE)) {
            evt.consume();
        }
    }//GEN-LAST:event_tbayarKeyTyped

    private void tbayarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbayarKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            int d, e, f;
            d = Integer.parseInt(hargahir.getText());
            e = Integer.parseInt(tbayar.getText());
            f = e-d;

            if (e < d) {
                JOptionPane.showMessageDialog(null, "Uang Kurang!");
            } else if("".equals(e)){
                JOptionPane.showMessageDialog(null, "Bayar Kosong!");
            }else{
                jkembalian.setText(""+f);
                simpan.setEnabled(true);
            }
        }
    }//GEN-LAST:event_tbayarKeyPressed

    private void tjmlhKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tjmlhKeyTyped
        char jmlh = evt.getKeyChar();
        if (!(Character.isDigit(jmlh) || (jmlh==KeyEvent.VK_BACK_SPACE) || jmlh==KeyEvent.VK_DELETE)) {
            evt.consume();
            autoSum(); 
            tambah.setEnabled(true);
        }
    }//GEN-LAST:event_tjmlhKeyTyped

    private void tjmlhKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tjmlhKeyReleased
        if (evt.getKeyCode()==KeyEvent.VK_ENTER) {
            autoSum();
            tambah.setEnabled(true);
        }
    }//GEN-LAST:event_tjmlhKeyReleased

    private void simpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_simpanActionPerformed
        Selesai();
        bcetak.setEnabled(true);
        reset();
        hargahir.setText("");
    }//GEN-LAST:event_simpanActionPerformed

    private void batalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_batalActionPerformed
        int i=keranjang.getSelectedRow();
        if ("".equals(kodebarang.getText())){
            JOptionPane.showMessageDialog(null, "Pilih Data untuk dibatalkan!");
        }else {
            Batal(); 
            reset(); 
            batal.setEnabled(false);
            tjmlh.setEnabled(false);
        }
    }//GEN-LAST:event_batalActionPerformed

    private void tambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tambahActionPerformed
        int stok = Integer.parseInt(tstok.getText());
        int jmlh = Integer.parseInt(tjmlh.getText());
    
        if (jmlh > stok) {
            JOptionPane.showMessageDialog(null, "Stok tidak cukup atau habis!");
        }else{
            TambahDetail();
            UpdateStock();
            loadData();
            reset();
            tjmlh.setEnabled(false);
            tambah.setEnabled(false);
            kosong.setEnabled(true);
            tbayar.setEnabled(true);
        }
    }//GEN-LAST:event_tambahActionPerformed

    private void miniMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_miniMouseClicked
        this.setState(this.ICONIFIED);
    }//GEN-LAST:event_miniMouseClicked

    private void transaksiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_transaksiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_transaksiActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(kasir.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(kasir.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(kasir.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(kasir.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new kasir().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton batal;
    private javax.swing.JButton bcetak;
    private javax.swing.JButton breset;
    private javax.swing.JLabel close;
    private javax.swing.JTextField hargahir;
    private javax.swing.JTextField hgbarang;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JLabel jkembalian;
    private javax.swing.JTextField kdbarang;
    private javax.swing.JTable keranjang;
    private javax.swing.JTextField kodebarang;
    private javax.swing.JButton kosong;
    private javax.swing.JLabel mini;
    private javax.swing.JComboBox<String> namabarang;
    private javax.swing.JButton simpan;
    private javax.swing.JTextField subtotal;
    private javax.swing.JButton tambah;
    private com.toedter.calendar.JDateChooser tanggal;
    private javax.swing.JTextField tbayar;
    private javax.swing.JTextField tdatetime;
    private javax.swing.JTextField tjmlh;
    private javax.swing.JTextField transaksi;
    private javax.swing.JTextField tstok;
    private javax.swing.JLabel waktu;
    // End of variables declaration//GEN-END:variables
}
