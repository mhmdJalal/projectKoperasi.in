<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cetak extends CI_Controller {
  public function __construct()
  {
    parent::__construct();
    $this->load->library('Pdf');
    $this->load->model('M_cetak');
  }

  public function index()
  {
      $data['title']  = "Koperasi.in Aja";

      $this->load->view('template/header', $data);
      $this->load->view('pages/index');
      $this->load->view('template/footer');
  }

  public function cetakBarang()
  {
    $data['tanggal'] = date('d-m-Y');
    $data['barang'] = $this->M_cetak->cetakBarang();

    $this->load->view('pages/bu_cetakBarang', $data);
  }

  public function cetakPenjualan()
  {
    $data['tanggal'] = date('d-m-Y');
    $data['penjualan'] = $this->M_cetak->get_query('q_penjualan')->result_array();
    $data['jual'] = $this->M_cetak->get_query('q_penjualan')->row();
    $data['subtotal'] = $this->M_cetak->get_sum_1('total_harga', 'q_penjualan');
    $data['jumlah'] = $this->M_cetak->get_sum_1('jumlah_brg', 'q_penjualan');

    $this->load->view('pages/bu_cetakPenjualan', $data);
  }

  public function cetak($kd_transaksi)
  {
    $data['tanggal'] = date('d-m-Y');
    $data['count_total'] = $this->M_cetak->get_sum('total_harga', 'q_penjualan', 'no_transaksi', $kd_transaksi);
    $data['kode'] = $this->M_cetak->get_query_where('q_penjualan', 'no_transaksi', $kd_transaksi)->row_array();
    $data['pembelian'] = $this->M_cetak->get_query_where('q_penjualan', 'no_transaksi', $kd_transaksi)->result();

    $this->load->view('pages/bu_cetakStruk', $data);
  }

  public function filterStruk()
  {
    $data['title'] = "Filter Struk | Koperasi.in";
    $data['penjualan'] = $this->M_cetak->get_query('q_penjualan')->result_array();

    $this->load->view('template/header', $data);
    $this->load->view('pages/v_filterStruk', $data);
    $this->load->view('template/footer');
  }

}
/* End of file ${TM_FILENAME:cetak.php} */
/* Location: ./${TM_FILEPATH/.+((?:application).+)/Cetak/:application/controllers/cetak.php} */
