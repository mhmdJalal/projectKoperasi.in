<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_cetak extends CI_Model {
  public function __construct()
  {
    parent::__construct();
    $this->load->database();
  }

  function getId($table, $field, $value){
    $this->db->where($field, $value);
    $query = $this->db->get($table);
    return $query->row_array();
  }

  function cetakBarang(){
    $query = $this->db->get('tb_barang');
    return $query->result_array();
  }

  function cetakPenjualan(){
    $query = $this->db->get('q_penjualan');
    return $query;
  }

  function get_sum($field, $table, $primary, $value){
    $this->db->where($primary, $value);
    $this->db->select_sum($field);
    $query = $this->db->get($table);
    return $query->row()->$field;
  }

  public function get_sum_1($field, $table)
  {
    $this->db->select_sum($field);
    $query = $this->db->get($table);
    return $query->row()->$field;
  }

  function cetakStruk(){
    $this->db->join('tb_jual', 'tb_jual.no_transaksi = q_keranjang.kd_transaksi');
    return $this->db->get('q_keranjang');
  }

  public function get_query($table)
  {
    return $this->db->get($table);
  }

  public function get_query_where($table, $primary, $value)
  {
    $this->db->where($primary, $value);
    return $this->db->get($table);
  }

}
/* End of file ${TM_FILENAME:m_cetak.php} */
/* Location: ./${TM_FILEPATH/.+((?:application).+)/M_cetak/:application/models/m_cetak.php} */
