<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= $title ?></title>

  <!-- start: Css -->
  <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/bootstrap.min.css') ?>">

  <!-- plugins -->
  <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/plugins/font-awesome.min.css') ?>"/>
  <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/plugins/datatables.bootstrap.min.css') ?>"/>
  <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/plugins/animate.min.css') ?>"/>
  <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/plugins/nouislider.min.css') ?>"/>
  <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/plugins/simple-line-icons.css') ?>"/>
  <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/plugins/select2.min.css') ?>"/>
  <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/plugins/ionrangeslider/ion.rangeSlider.css') ?>"/>
  <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/plugins/ionrangeslider/ion.rangeSlider.skinFlat.css') ?>"/>
  <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/plugins/bootstrap-material-datetimepicker.css') ?>"/>
  <link href="<?= base_url('assets/css/style.css') ?>" rel="stylesheet">
  <!-- end: Css -->

</head>

<body>
