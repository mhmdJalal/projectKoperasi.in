<?php
	$pdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
	$pdf->SetTitle('Koperasi.In');
	$pdf->SetTopMargin(20);
	$pdf->setFooterMargin(20);
	$pdf->SetAutoPageBreak(true);
	$pdf->SetAuthor('SMK WIKRAMA BOGOR');
	$pdf->SetDisplayMode('real', 'default');
	$pdf->AddPage();
	$i=0;
	$html='<h2 align="center">Koperasi.In</h2>
  <p align="center">Jl. Raya wangun Kelurahan Sindangsari Kecamatan Bogor Timur <br>
    Kota Bogor, Jawa Barat, Indonesia</p>
  <h4 align="center">Data Barang</h4>
	<table border="1" bgcolor="#1297E0" cellpadding="1">
	<tr style="color: #ffffff">
    <td align="center">Kode Barang</td>
    <td align="center">Nama Barang</td>
    <td align="center">Harga Barang</td>
    <td align="center">Jumlah</td>
    <td align="center">Tanggal Masuk</td>
	</tr>';
	foreach ($barang as $row)
	{
		$html.='
		<tr bgcolor="#ffffff">
			<td>'.@$row['kd_barang'].'</td>
			<td>'.@$row['nm_barang'].'</td>
			<td>Rp '.@$row['harga_barang'].'</td>
			<td align="center">'.@$row['jumlah'].'</td>
			<td align="center">'.@$row['tgl_masuk'].'</td>
		</tr>';
	}
	$html.='</table>';
	$pdf->writeHTML($html, true, false, true, false, '');
	$pdf->Output('data_barang_'.$tanggal.'.pdf', 'I');
?>
