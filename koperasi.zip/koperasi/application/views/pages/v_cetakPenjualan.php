<?php
	$pdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
	$pdf->SetTitle('Koperasi.In');
	$pdf->SetTopMargin(20);
	$pdf->setFooterMargin(20);
	$pdf->SetAutoPageBreak(true);
	$pdf->SetAuthor('SMK WIKRAMA BOGOR');
	$pdf->SetDisplayMode('real', 'default');
	$pdf->AddPage();
	$i=0;
	$html='<h2 align="center">Koperasi.In</h2>
  <p align="center">Jl. Raya wangun Kelurahan Sindangsari Kecamatan Bogor Timur <br>
    Kota Bogor, Jawa Barat, Indonesia</p>
  <h4 align="center">Data Penjualan</h4>
	<table border="1" bgcolor="#1297E0" cellpadding="1">
	<tr style="color: #ffffff">
      <th align="center" style="font-size:12px">No Transaksi</th>
      <th align="center">Total Harga</th>
      <th align="center">Bayar</th>
      <th align="center">Kembalian</th>
      <th align="center">Jumlah Barang</th>
      <th align="center">Tanggal</th>
      <th align="center">Jam</th>
	</tr>';
	foreach ($penjualan as $row)
	{
		$html.='
		<tr bgcolor="#ffffff">
			<td>'.@$row['no_transaksi'].'</td>
			<td>Rp '.@$row['total_harga'].'</td>
			<td>Rp '.@$row['bayar'].'</td>
			<td>Rp '.@$row['kembalian'].'</td>
			<td align="center">'.@$row['jumlah_brg'].'</td>
			<td align="center">'.@$row['tanggal'].'</td>
			<td align="center">'.@$row['jam'].'</td>
		</tr>';
	}
	$html.='</table>';
	$pdf->writeHTML($html, true, false, true, false, '');
	$pdf->Output('data_penjualan_'.$tanggal.'.pdf', 'I');
?>
