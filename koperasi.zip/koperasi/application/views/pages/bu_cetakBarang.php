<h2 align="center" style="margin-top:20px">KOPERASI.IN</h2>
<p align="center">Jl. Raya wangun Kelurahan Sindangsari Kecamatan Bogor Timur <br>
  Kota Bogor, Jawa Barat, Indonesia</p>
<br>
<table border="1" align="center">
  <h3 align="center">Data Barang Koperasi.in</h3>
  <thead>
    <tr>
      <th>Kode Barang</th>
      <th>Nama Barang</th>
      <th>Harga Barang</th>
      <th>Jumlah</th>
      <th>Tanggal Masuk</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($barang as $row): ?>
      <tr>
        <td><?= $row['kd_barang'] ?></td>
        <td><?= $row['nm_barang'] ?></td>
        <td><?= $row['harga_barang'] ?></td>
        <td><?= $row['jumlah'] ?></td>
        <td><?= $row['tgl_masuk'] ?></td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>
<button type="submit" name="print" class="btn btn-default" onclick="window.print()">Cetak</button>
