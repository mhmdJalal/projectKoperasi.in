<form class="form-horizontal" action="" method="post" style="margin-top:2%">
  <table class="table-hover table-striped" align="center">
    <h3 align="center">Data Penjualan</h3>
    <thead>
      <th>No Transaksi</th>
      <th>Nama Barang</th>
      <th>Harga Barang</th>
      <th>Jumlah</th>
      <th>Subtotal</th>
      <th>Tanggal Pembelian</th>
    </thead>
    <tbody>
      <?php foreach ($penjualan as $row): ?>
        <tr>
          <td><a href="<?= base_url('Cetak/cetak/'.$row['no_transaksi']) ?>"> <?= $row['no_transaksi'] ?> </a></td>
          <td><?= $row['nm_barang'] ?></td>
          <td><?= $row['harga_barang'] ?></td>
          <td><?= $row['jumlah_brg'] ?></td>
          <td><?= $row['total_harga'] ?></td>
          <td><?= $row['tanggal'] ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</form>
