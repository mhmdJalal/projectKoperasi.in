<h2 align="center" style="margin-top:20px">KOPERASI.IN</h2>
<p align="center">Jl. Raya wangun Kelurahan Sindangsari Kecamatan Bogor Timur <br>
  Kota Bogor, Jawa Barat, Indonesia</p>



<br>
<table border="1" align="center" cellpadding="1">
  <h3 align="center">Data Hasil Penjualan Koperasi.in</h3>
  <thead>
    <tr>
      <th>No Transaksi</th>
      <th>Nama Barang</th>
      <th>Jumlah</th>
      <th>Tanggal</th>
      <th>Jam</th>
      <th>Subtotal</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($penjualan as $row): ?>
      <tr>
        <td><?= $row['no_transaksi'] ?></td>
        <td><?= $row['nm_barang'] ?></td>
        <td align="center"><?= $row['jumlah_brg'] ?></td>
        <td><?= $row['tanggal'] ?></td>
        <td><?= $row['jam'] ?></td>
        <td>Rp <?= $row['total_harga'] ?></td>
      </tr>
    <?php endforeach; ?>
      <tr>
        <td colspan="2" align="right">Jumlah Barang Terjual :</td>
        <td><?= $jumlah ?></td>
        <td></td>
        <td></td>
        <td></td>
      </tr>
      <tr>
        <td colspan="5" align="right">Grandtotal :</td>
        <td>Rp <?= $subtotal ?></td>
      </tr>
  </tbody>
</table>
<button type="submit" name="print" class="btn btn-default" onclick="window.print()">Cetak</button>
