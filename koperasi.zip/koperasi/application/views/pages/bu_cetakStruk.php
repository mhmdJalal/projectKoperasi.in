<h2 align="center" style="margin-top:20px">KOPERASI.IN</h2>
<p align="center">Jl. Raya wangun Kelurahan Sindangsari Kecamatan Bogor Timur <br>
  Kota Bogor, Jawa Barat, Indonesia</p>



<br>
<table align="center">
  <thead>
    <tr>
      <td colspan="3">No Transaksi  :  <?= $kode['no_transaksi'] ?></td>
      <td>Tanggal  :  <?= $kode['tanggal'] ?></td>
    </tr>
    <tr>
      <td colspan="3"></td>
      <td>Jam  :  <?= $kode['jam'] ?><br></td>
    </tr>
    <tr>
      <td colspan="4"></td>
    </tr>
    <tr>
      <td colspan="4"></td>
    </tr>
    <tr>
      <td colspan="4"></td>
    </tr>
    <tr>
      <th width="100px">Nama Barang</th>
      <th width="100px" align="center">Jumlah</th>
      <th>Harga Satuan</th>
      <th width="100px" align="center">Total Harga</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($pembelian as $row): ?>
      <tr>
        <td><?= $row->nm_barang ?></td>
        <td align="center"><?= $row->jumlah_brg ?></td>
        <td align="center">Rp <?= $row->harga_barang ?></td>
        <td align="center">Rp <?= $row->total_harga ?></td>
      </tr>
    <?php endforeach; ?>
      <tr>
        <td colspan="4"></td>
      </tr>
      <tr>
        <td colspan="3" align="right">Total harga</td>
        <td align="center"><?= "Rp ".$count_total ?></td>
      </tr>
      <tr>
        <td colspan="3" align="right">Bayar</td>
        <td align="center"><?= "Rp ".$kode['bayar'] ?></td>
      </tr>
      <tr>
        <td colspan="3" align="right">Kembalian</td>
        <td align="center"><?= "Rp ".$kode['kembalian'] ?></td>
      </tr>
  </tbody>
</table>
<p align="center">
Terima Kasih sudah berbelanja disini,<br>
www.ngulikTime.com
</p>
<p align="left" style="margin-left:33%">
  Kritik dan saran <br>
  081-9202-2313 <br>
  ngulikTime@official.com
</p>
<button type="submit" onclick="window.print()" name="button">Cetak</button>
