<?php
	$pdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
	$pdf->SetTitle('Koperasi.In');
	$pdf->SetTopMargin(20);
	$pdf->setFooterMargin(20);
	$pdf->SetAutoPageBreak(true);
	$pdf->SetAuthor('SMK WIKRAMA BOGOR');
	$pdf->SetDisplayMode('real', 'default');
	$pdf->AddPage();
	$i=0;
	$html='<h2 align="center">Koperasi.In</h2>
  <p align="center">Jl. Raya wangun Kelurahan Sindangsari Kecamatan Bogor Timur <br>
    Kota Bogor, Jawa Barat, Indonesia</p>

    No Transaksi  :  '.$kode['no_transaksi'].'<br>
    Tanggal       :  '.$kode['tanggal'].'<br>
    Jam           :  '.$kode['jam'].'<br><br>

	<table>
    <thead>
    	<tr>
        <td>Nama Barang</td>
        <td align="center">Jumlah</td>
        <td>Harga Satuan</td>
        <td>Total Harga</td>
    	</tr>
    </thead>
    <tbody>
      <tr>
        <td colspan="4"></td>
      </tr>';
	foreach ($pembelian as $row)
	{
		$html.='
  		<tr bgcolor="#ffffff">
        <td>'.$row->nm_barang.'</td>
        <td align="center">'.$row->jumlah_qty.'</td>
        <td>Rp '.$row->harga_barang.'</td>
        <td>Rp '.$row->subtotal.'</td>
  		</tr>';
	}
	$html.='
      <tr>
        <td colspan="4"></td>
      </tr>
      <tr>
        <td colspan="3" align="right">Total harga</td>
        <td align="center">Rp '.$kode['total_harga'].'</td>
      </tr>
      <tr>
        <td colspan="3" align="right">Bayar</td>
        <td align="center">Rp '.$kode['harga_barang'].'</td>
      </tr>
      <tr>
        <td colspan="3" align="right">Kembalian</td>
        <td align="center">Rp '.$kode['harga_barang'].'</td>
      </tr>
    </tbody>
  </table>
  <p align="center">
  Terima Kasih sudah berbelanja disini,<br>
  www.ngulikTime.com
  </p>

  Kritik dan saran <br>
  081-9202-2313 <br>
  ngulikTime@official.com
  ';
	$pdf->writeHTML($html, true, false, true, false, '');
	$pdf->Output('Struk_pembelian_'.$tanggal.'.pdf', 'I');
?>
