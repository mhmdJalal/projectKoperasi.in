<h1 class="text-center">
  Koperasi.in Aja
</h1>
<div class="container" style="margin-left:20%">
  <div class="col-md-12" style="padding:20px;">
                     <div class="col-md-12 padding-0">
                         <div class="col-md-8 padding-0">
                             <div class="col-md-12 padding-0">
                                 <div class="col-md-6">
                                     <div class="panel box-v1">
                                       <div class="panel-heading bg-white border-none">
                                         <div class="col-md-6 col-sm-6 col-xs-6 text-left padding-0">
                                           <h4 class="text-left">Cetak Barang</h4>
                                         </div>
                                         <div class="col-md-6 col-sm-6 col-xs-6 text-right">
                                            <h4>
                                            <span class="icon-social-dropbox icons icon text-right"></span>
                                            </h4>
                                         </div>
                                       </div>
                                       <div class="panel-body text-center">
                                         <a href="<?= base_url('Cetak/cetakBarang') ?>">
                                           <h1>
                                           <span class="icon-printer icons icon text-right"></span>
                                         </h1>
                                       </a>
                                         <hr/>
                                       </div>
                                     </div>
                                 </div>
                                 <div class="col-md-6">
                                     <div class="panel box-v1">
                                       <div class="panel-heading bg-white border-none">
                                         <div class="col-md-6 col-sm-6 col-xs-6 text-left padding-0">
                                           <h4 class="text-left">Cetak Penjualan</h4>
                                         </div>
                                         <div class="col-md-6 col-sm-6 col-xs-6 text-right">
                                            <h4>
                                            <span class="icon-basket-loaded icons icon text-right"></span>
                                            </h4>
                                         </div>
                                       </div>
                                       <div class="panel-body text-center">
                                         <a href="<?= base_url('Cetak/cetakPenjualan') ?>">
                                           <h1>
                                           <span class="icon-printer icons icon text-right"></span>
                                         </h1>
                                       </a>
                                         <hr/>
                                       </div>
                                     </div>
                                 </div>
                             </div>
                           </div>
                         </div>
                         </div>
</div>
